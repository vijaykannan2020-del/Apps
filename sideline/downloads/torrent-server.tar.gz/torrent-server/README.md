# Sideline private torrent bridge

This separate server receives an authorized magnet from your private web app and turns the selected file into a signed HTTPS video URL. Infuse can play the direct stream; Safari can use the optional H.264/AAC HLS conversion. No torrent providers or channel packages are included.

The website does not host this process. Deploy the bridge on an always-on Linux VPS, or a computer with Docker and a reachable HTTPS hostname. No hosting account or paid resources are created by this project.

## Deploy with Docker

Use a host that permits BitTorrent traffic. A starting point for one viewer is 2 CPU cores, 2–4 GB RAM and at least 40 GB free disk; conversion can need more CPU for demanding videos. Point a DNS hostname to the machine. Allow inbound TCP 80/443 and TCP/UDP 51413. The API listens behind Caddy and requires a key; it is not a public relay.

1. Copy this directory to the host and install Docker Engine with Docker Compose.
2. With Node.js 22+ available, run `node setup.mjs streams.your-domain.com`. This creates a private `.env` without overwriting an existing one. Change the hostname before deployment if you used the example.
3. Run `docker compose up -d --build`. Caddy obtains HTTPS automatically when DNS and ports are reachable. Check `docker compose ps` and `docker compose logs --tail=50 bridge`.
4. Open your web app in Safari, go to **My sources → Torrent server**, and enter `https://streams.your-domain.com` plus the `API_KEY` from your host's `.env`. Never paste that key into chat. Keep `STREAM_SECRET` on the server.
5. Select **Stream via my server** on a torrent result, wait for metadata, choose the correct file, then choose **Direct / Infuse** or **Safari HLS**. A title with multiple files is not guessed from the largest file; choose the episode you want.

To create the `.env` with Docker instead of a host Node installation, run `docker run --rm -v "$PWD:/app" -w /app node:24-bookworm-slim node setup.mjs streams.your-domain.com`. The generated file may be owned by root on Linux; adjust its ownership to your account while preserving mode 600.

## What to expect

- This version uses DHT and a server-controlled public tracker. It strips arbitrary peer, webseed and metadata URLs from submitted magnets; private trackers and webseed-only torrents are not supported.
- Public peers must actually have the torrent. Metadata retrieval stops after 60 seconds if none responds. The bridge cannot make a dead torrent available.
- Direct streams support byte ranges for seeking. Infuse handles more containers and codecs than Safari. Safari HLS converts video up to 720p and audio to AAC; the first segment can take time to prepare, and seeking is limited to converted portions until conversion finishes.
- Native TCP peers and DHT are supported. uTP and optional WebRTC dependencies are not required for this Docker build. The missing optional uTP package may produce a startup notice; TCP transfers still work.
- BitTorrent downloads can upload pieces to peers. "Private" means your app and bridge access are restricted, not that BitTorrent traffic is anonymous.
- Video data is cached on the host. Each torrent has a declared size limit; at most three sessions run by default. HLS conversion uses extra space. Plan disk capacity for the configured session count. Stop a session in the app to remove its data, or let its idle timeout clean it up. Completed files are not a permanent library. On restart, app-owned session directories left by an interrupted previous run are removed. Use a dedicated DATA_DIR for this service.
- Playback links are bearer capabilities valid for six hours by default. Do not share them. The API key stays in browser session storage and is not put into video links or the site's source.
- `APP_ORIGIN` must match your website origin. The default matches the private Sideline site. Server API calls and playlist/video delivery allow that origin; Infuse uses signed links without an Origin header.
- The `.env` and `node_modules` are ignored by source control. There are no source-provider credentials in this package.

## Run without Docker

Install Node.js 22+ and FFmpeg, then run `npm ci --omit=optional`. Set the variables in `.env.example` in your process environment and run `npm start`. Bind behind an HTTPS reverse proxy. `HOST` defaults to loopback, `PORT` to 8787, `PEER_PORT` to 51413, and `DATA_DIR` to `./torrent-data`. `ALLOW_HTTP=1` is for local development only; the published iPhone app requires an HTTPS server URL.

## Tests

`npm test` creates an original synthetic video with FFmpeg, seeds it on a local torrent client, downloads it with a separate local client, checks authentication/CORS, verifies exact byte ranges, converts it to HLS, verifies signed segment access, then deletes the session. It needs permission to bind local sockets. Tests do not contact public torrent swarms or use commercial movies.
