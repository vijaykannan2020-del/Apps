import http from 'node:http';
import crypto from 'node:crypto';
import path from 'node:path';
import { promises as fs, createReadStream } from 'node:fs';
import { pipeline } from 'node:stream';
import { spawn } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import WebTorrent from 'webtorrent';

const VIDEO = /\.(mp4|m4v|mkv|webm|mov|avi|ts|m2ts|mpg|mpeg|ogv)$/i;
const MIME = { mp4:'video/mp4',m4v:'video/mp4',mkv:'video/x-matroska',webm:'video/webm',mov:'video/quicktime',avi:'video/x-msvideo',ts:'video/mp2t',m2ts:'video/mp2t',mpg:'video/mpeg',mpeg:'video/mpeg',ogv:'video/ogg' };
export function canonicalMagnet(value) {
  if (typeof value !== 'string' || value.length > 20000 || !value.startsWith('magnet:?')) throw new Error('A valid BitTorrent magnet is required.');
  const q = new URLSearchParams(value.slice(8));
  const hash = q.getAll('xt').map(x=>/^urn:btih:([a-f0-9]{40}|[a-z2-7]{32})$/i.exec(x)).find(Boolean)?.[1];
  if (!hash) throw new Error('Only BitTorrent v1 or hybrid info hashes are supported.');
  // Do not accept arbitrary webseed, metadata, peer, or tracker URLs from input.
  const normalized=hash.length===32?hash.toUpperCase():hash.toLowerCase();const clean = new URLSearchParams({xt:'urn:btih:'+normalized});
  if(q.has('dn'))clean.set('dn',q.get('dn').slice(0,250));
  return {magnet:'magnet:?'+clean.toString().replace(/^xt=urn%3Abtih%3A/i,'xt=urn:btih:'),hash:normalized};
}
export function byteRange(header,length) {
  if(!header)return {start:0,end:length-1,partial:false};
  const m=/^bytes=(\d*)-(\d*)$/.exec(header);if(!m||(!m[1]&&!m[2]))return null;
  let start=m[1]?Number(m[1]):Math.max(0,length-Number(m[2]));
  let end=m[1]?(m[2]?Math.min(Number(m[2]),length-1):length-1):length-1;
  if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||start>=length||end<start)return null;
  return {start,end,partial:true};
}
export function configuration(env=process.env) {
  if(!env.API_KEY||env.API_KEY.length<32)throw new Error('Set API_KEY to a random value of at least 32 characters.');
  if(!env.STREAM_SECRET||env.STREAM_SECRET.length<32)throw new Error('Set STREAM_SECRET to a different random value of at least 32 characters.');
  if(env.API_KEY===env.STREAM_SECRET)throw new Error('API_KEY and STREAM_SECRET must differ.');
  const publicURL=new URL(env.PUBLIC_URL||'https://stream.example.com');
  if(publicURL.protocol!=='https:'&&env.ALLOW_HTTP!=='1')throw new Error('PUBLIC_URL must use HTTPS.');
  return {apiKey:env.API_KEY,secret:env.STREAM_SECRET,publicURL:publicURL.origin,host:env.HOST||'127.0.0.1',port:Number(env.PORT||8787),dataDir:path.resolve(env.DATA_DIR||'./torrent-data'),origin:env.APP_ORIGIN||'https://sideline-live-tv-8742.verdantcaper.chatgpt.site',maxSessions:Number(env.MAX_SESSIONS||3),maxBytes:Number(env.MAX_TORRENT_GB||12)*1024**3,idleMs:Number(env.IDLE_MINUTES||30)*60000,ticketMs:Number(env.TICKET_HOURS||6)*3600000,maxTranscodes:Number(env.MAX_TRANSCODES||1),ffmpeg:env.FFMPEG_PATH||'ffmpeg',peerPort:Number(env.PEER_PORT||51413)};
}
export function createStreamingServer(config,clientOverride) {
  const client=clientOverride||new WebTorrent({torrentPort:config.peerPort,dhtPort:config.peerPort,utp:false,natUpnp:false,natPmp:false,maxConns:50,webSeeds:false,tracker:{announce:['udp://tracker.opentrackr.org:1337/announce']},blocklist:['0.0.0.0/8','10.0.0.0/8','127.0.0.0/8','169.254.0.0/16','172.16.0.0/12','192.168.0.0/16','224.0.0.0/4']});
  const jobs=new Map(),hashes=new Map(),rates=new Map();let closing=false;
  client.on('error',()=>{});
  const signature=(id,index,expires)=>crypto.createHmac('sha256',config.secret).update(`${id}:${index}:${expires}`).digest('base64url');
  const equal=(a,b)=>{const x=crypto.createHash('sha256').update(String(a)).digest(),y=crypto.createHash('sha256').update(String(b)).digest();return crypto.timingSafeEqual(x,y)};
  function mediaURL(job,index,kind='direct') {
    const expires=Date.now()+config.ticketMs,q=new URLSearchParams({e:String(expires),t:signature(job.id,index,expires)});
    const file=job.torrent.files[index],ext=path.extname(file.name).toLowerCase()||'.mp4';
    return config.publicURL+(kind==='hls'?`/hls/${job.id}/${index}/index.m3u8`:`/media/${job.id}/${index}/video${ext}`)+'?'+q;
  }
  function json(res,status,value){if(res.headersSent)return;res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(value))}
  function view(job){return {id:job.id,state:job.state,error:job.error||null,name:job.torrent?.name||null,peers:job.torrent?.numPeers||0,downloadSpeed:job.torrent?.downloadSpeed||0,progress:job.torrent?.progress||0,selectedFile:job.selectedFile??null,files:job.state==='ready'?job.torrent.files.map((f,index)=>({index,name:f.name,length:f.length,video:VIDEO.test(f.name)})).filter(f=>f.video):[],transcode:job.hls?.state||null,transcodeError:job.hls?.error||null,playback:job.playback||null}}
  function fail(job,message){job.state='error';job.error=message;clearTimeout(job.metadataTimer)}
  async function drop(job){if(!jobs.has(job.id))return;jobs.delete(job.id);hashes.delete(job.hash);clearTimeout(job.metadataTimer);if(job.hls?.process)job.hls.process.kill('SIGTERM');for(const request of job.requests)request.destroy();if(job.torrent&&!job.torrent.destroyed)await new Promise(resolve=>client.remove(job.torrent,{destroyStore:true},()=>resolve()));await fs.rm(path.join(config.dataDir,job.id),{recursive:true,force:true})}
  function select(job,index){const file=job.torrent.files[index];if(!file||file.length<=0||!VIDEO.test(file.name))throw new Error('Choose a video file from this torrent.');if(job.selectedFile!==undefined&&job.selectedFile!==index){if(job.hls?.process)job.hls.process.kill('SIGTERM');job.hls=null;job.playback=null}for(const f of job.torrent.files)f.deselect();file.select();job.selectedFile=index;job.touched=Date.now();return file}
  async function body(req){let data='';for await(const chunk of req){data+=chunk;if(data.length>25000)throw new Error('Request is too large.')}return JSON.parse(data||'{}')}
  function allowedTicket(url,id,index){const e=Number(url.searchParams.get('e')),t=url.searchParams.get('t');return Number.isSafeInteger(e)&&e>Date.now()&&e<Date.now()+config.ticketMs+60000&&t&&equal(t,signature(id,index,e))}
  async function startHLS(job,index){
    if(job.hls?.index===index&&job.hls.state!=='error')return;
    const active=[...jobs.values()].filter(j=>j.hls?.process&&!j.hls.process.killed&&['starting','ready'].includes(j.hls.state)).length;
    if(active>=config.maxTranscodes)throw new Error('Another Safari conversion is running. Stop it or use Direct / Infuse.');
    const dir=path.join(config.dataDir,job.id,'hls-'+index);await fs.rm(dir,{recursive:true,force:true});await fs.mkdir(dir,{recursive:true});
    const input=mediaURL(job,index).replace(config.publicURL,`http://127.0.0.1:${server.address().port}`);
    const args=['-hide_banner','-loglevel','error','-nostdin','-rw_timeout','30000000','-i',input,'-map','0:v:0?','-map','0:a:0?','-sn','-c:v','libx264','-preset','veryfast','-crf','23','-vf','scale=w=min(1280\\,iw):h=-2','-c:a','aac','-ac','2','-b:a','128k','-f','hls','-hls_time','6','-hls_playlist_type','event','-hls_list_size','0','-hls_flags','independent_segments+temp_file','-hls_segment_filename',path.join(dir,'segment-%06d.ts'),path.join(dir,'index.m3u8')];
    job.playback=null;const process=spawn(config.ffmpeg,args,{stdio:['ignore','ignore','pipe']});job.hls={index,dir,process,state:'starting',error:null};
    process.stderr.on('data',()=>{}); // Do not log signed playback URLs from FFmpeg errors.
    process.on('error',()=>{if(job.hls?.process===process){job.hls.state='error';job.hls.error='FFmpeg could not start. Check the server installation.';job.playback=null}});
    process.on('exit',code=>{if(job.hls?.process===process){job.hls.state=code===0?'complete':'error';if(code!==0){job.hls.error='Conversion stopped. The torrent may be unavailable or its media unsupported. Try Direct / Infuse.';job.playback=null}}});
  }
  async function updateHLS(job){if(!job.hls||job.hls.state==='error')return;try{const text=await fs.readFile(path.join(job.hls.dir,'index.m3u8'),'utf8');if(text.includes('#EXTINF:')){if(job.hls.state!=='complete')job.hls.state='ready';job.playback={mode:'hls',url:mediaURL(job,job.hls.index,'hls')}}}catch{}}
  const server=http.createServer(async(req,res)=>{
    const origin=req.headers.origin;
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
    if(origin&&origin!==config.origin){json(res,403,{error:'This origin is not allowed.'});return}
    if(origin){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Expose-Headers','Content-Range, Accept-Ranges, Content-Length')}
    if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Methods':'GET, HEAD, POST, DELETE, OPTIONS','Access-Control-Allow-Headers':'Authorization, Content-Type, Range','Access-Control-Max-Age':'600'});res.end();return}
    try{
      const url=new URL(req.url,'http://server.local'),pathname=url.pathname;
      if(pathname==='/healthz'){json(res,200,{ok:true});return}
      if(pathname.startsWith('/api/')){
        if(!equal(req.headers.authorization||'','Bearer '+config.apiKey)){json(res,401,{error:'Invalid server access key.'});return}
        const identity=req.socket.remoteAddress,now=Date.now(),rate=rates.get(identity)||{time:now,count:0};if(now-rate.time>60000){rate.time=now;rate.count=0}if(++rate.count>180){json(res,429,{error:'Too many requests. Wait a moment.'});return}rates.set(identity,rate);
        if(pathname==='/api/info'&&req.method==='GET'){json(res,200,{name:'Sideline Torrent Bridge',version:'1.0.0',features:['torrent-v1','direct','hls'],maxSessions:config.maxSessions});return}
        if(pathname==='/api/sessions'&&req.method==='GET'){json(res,200,{sessions:[...jobs.values()].map(view)});return}
        if(pathname==='/api/sessions'&&req.method==='POST'){
          let data,parsed;try{data=await body(req);parsed=canonicalMagnet(data.magnet)}catch(e){json(res,400,{error:e.message});return}
          const existing=jobs.get(hashes.get(parsed.hash));if(existing){existing.touched=Date.now();json(res,200,view(existing));return}
          if(jobs.size>=config.maxSessions){json(res,409,{error:'Session limit reached. Stop another torrent first.'});return}
          const id=crypto.randomUUID(),job={id,hash:parsed.hash,state:'metadata',touched:Date.now(),requests:new Set()};jobs.set(id,job);hashes.set(parsed.hash,id);await fs.mkdir(path.join(config.dataDir,id),{recursive:true});
          const torrent=client.add(parsed.magnet,{path:path.join(config.dataDir,id),deselect:true,destroyStoreOnDestroy:true,announce:['udp://tracker.opentrackr.org:1337/announce']});job.torrent=torrent;
          job.metadataTimer=setTimeout(()=>{if(job.state==='metadata'){fail(job,'No torrent metadata received. Peers may be unavailable.');if(!torrent.destroyed)torrent.destroy({destroyStore:true})}},60000);job.metadataTimer.unref();
          torrent.on('error',()=>fail(job,'The torrent could not be loaded. Peers may be unavailable.'));
          const ready=()=>{if(job.state!=='metadata')return;clearTimeout(job.metadataTimer);if(torrent.length>config.maxBytes){fail(job,'Torrent exceeds the configured cache size limit.');torrent.destroy({destroyStore:true});return}job.state='ready';if(!torrent.files.some(f=>VIDEO.test(f.name)))fail(job,'This torrent contains no supported video files.')};torrent.once('ready',ready);if(torrent.ready)ready();
          json(res,202,view(job));return;
        }
        const match=/^\/api\/sessions\/([a-f0-9-]{36})(?:\/(play))?$/.exec(pathname);
        if(match){const job=jobs.get(match[1]);if(!job){json(res,404,{error:'Session expired or not found.'});return}job.touched=Date.now();
          if(req.method==='DELETE'&&!match[2]){await drop(job);json(res,200,{ok:true});return}
          if(req.method==='GET'&&!match[2]){await updateHLS(job);json(res,200,view(job));return}
          if(req.method==='POST'&&match[2]==='play'){
            if(job.state!=='ready'){json(res,409,{error:'Wait for torrent metadata first.'});return}
            let data;try{data=await body(req)}catch{json(res,400,{error:'Invalid request.'});return}
            if(!Number.isInteger(data.fileIndex)||!['direct','hls'].includes(data.mode)){json(res,400,{error:'Select a video file and playback mode.'});return}
            try{select(job,data.fileIndex);if(data.mode==='hls'){await startHLS(job,data.fileIndex);await updateHLS(job)}else job.playback={mode:'direct',url:mediaURL(job,data.fileIndex)}}catch(e){json(res,400,{error:e.message});return}
            json(res,job.playback?200:202,view(job));return;
          }
        }
        json(res,404,{error:'Unknown API endpoint.'});return;
      }
      const match=/^\/(media|hls)\/([a-f0-9-]{36})\/(\d+)\/([a-zA-Z0-9_.-]+)$/.exec(pathname);
      if(match&&['GET','HEAD'].includes(req.method)){
        const [,kind,id,indexText,name]=match,index=Number(indexText),job=jobs.get(id);
        if(!allowedTicket(url,id,index)){json(res,401,{error:'Playback link expired or invalid.'});return}
        if(!job||job.state!=='ready'||!job.torrent.files[index]){json(res,404,{error:'Video session unavailable.'});return}job.touched=Date.now();
        if(kind==='media'){
          const file=job.torrent.files[index];if(!VIDEO.test(file.name)){json(res,404,{error:'Not a video file.'});return}const range=byteRange(req.headers.range,file.length);
          if(!range){res.writeHead(416,{'Content-Range':'bytes */'+file.length});res.end();return}
          const headers={'Content-Type':MIME[path.extname(file.name).slice(1).toLowerCase()]||'application/octet-stream','Accept-Ranges':'bytes','Content-Length':range.end-range.start+1,'Cache-Control':'private, no-store'};if(range.partial)headers['Content-Range']=`bytes ${range.start}-${range.end}/${file.length}`;
          res.writeHead(range.partial?206:200,headers);if(req.method==='HEAD'){res.end();return}
          const source=file.createReadStream({start:range.start,end:range.end});job.requests.add(source);res.on('close',()=>{source.destroy();job.requests.delete(source)});pipeline(source,res,()=>job.requests.delete(source));return;
        }
        if(!job.hls||job.hls.index!==index||!(name==='index.m3u8'||/^segment-\d{6}\.ts$/.test(name))){json(res,404,{error:'HLS stream not ready.'});return}
        const location=path.join(job.hls.dir,name);
        if(name==='index.m3u8'){let text;try{text=await fs.readFile(location,'utf8')}catch{json(res,503,{error:'Video is buffering. Try again shortly.'});return}text=text.split('\n').map(line=>line&&!line.startsWith('#')?line+'?'+url.searchParams.toString():line).join('\n');res.writeHead(200,{'Content-Type':'application/vnd.apple.mpegurl','Cache-Control':'no-store'});res.end(req.method==='HEAD'?undefined:text);return}
        let stat;try{stat=await fs.stat(location)}catch{json(res,404,{error:'Segment not ready.'});return}res.writeHead(200,{'Content-Type':'video/mp2t','Content-Length':stat.size,'Cache-Control':'private, no-store'});if(req.method==='HEAD')res.end();else pipeline(createReadStream(location),res,()=>{});return;
      }
      json(res,404,{error:'Not found.'});
    }catch{if(!res.headersSent)json(res,500,{error:'Server could not complete the request.'});else res.destroy()}
  });
  server.requestTimeout=30000;server.headersTimeout=15000;
  const cleanup=setInterval(()=>{const now=Date.now();for(const job of jobs.values())if(now-job.touched>config.idleMs)drop(job).catch(()=>{});for(const [key,r]of rates)if(now-r.time>120000)rates.delete(key)},30000);cleanup.unref();
  async function close(){if(closing)return;closing=true;clearInterval(cleanup);await Promise.all([...jobs.values()].map(drop));await new Promise(resolve=>server.close(resolve));await new Promise(resolve=>client.destroy(()=>resolve()))}
  return {server,client,jobs,close};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){
  try{const config=configuration();await fs.mkdir(config.dataDir,{recursive:true});for(const entry of await fs.readdir(config.dataDir,{withFileTypes:true}))if(entry.isDirectory()&&/^[a-f0-9-]{36}$/.test(entry.name))await fs.rm(path.join(config.dataDir,entry.name),{recursive:true,force:true});const app=createStreamingServer(config);app.server.listen(config.port,config.host,()=>console.log('Sideline Torrent Bridge started. API and playback authentication enabled.'));for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>app.close().then(()=>process.exit(0)))}catch(error){console.error(error.message);process.exitCode=1}
}
