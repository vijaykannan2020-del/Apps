import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {once} from 'node:events';
import {spawnSync} from 'node:child_process';
import WebTorrent from 'webtorrent';
import {canonicalMagnet,byteRange,createStreamingServer} from '../server.mjs';

test('magnet input is canonicalized and never accepts arbitrary fetch URLs',()=>{
  const {magnet}=canonicalMagnet('magnet:?xt=urn:btih:'+'a'.repeat(40)+'&xs=http://127.0.0.1/private&ws=http://169.254.169.254/&tr=http://localhost/announce');
  assert(!magnet.includes('xs=')&&!magnet.includes('ws=')&&!magnet.includes('tr='));
  assert.throws(()=>canonicalMagnet('https://example.com/file.torrent'));
  assert.throws(()=>canonicalMagnet('magnet:?xt=urn:btih:invalid'));
});
test('video ranges support full, seek and suffix requests',()=>{
  assert.deepEqual(byteRange('bytes=10-19',100),{start:10,end:19,partial:true});
  assert.deepEqual(byteRange('bytes=-10',100),{start:90,end:99,partial:true});
  assert.equal(byteRange('bytes=100-',100),null);
  assert.equal(byteRange('bytes=0-1,3-4',100),null);
});
const clientOptions={dht:false,tracker:false,lsd:false,utp:false,natUpnp:false,natPmp:false};
async function poll(fn,limit=15000){const until=Date.now()+limit;while(Date.now()<until){const value=await fn();if(value)return value;await new Promise(r=>setTimeout(r,100))}throw new Error('Timed out waiting for local torrent test')}
test('real local torrent → authenticated byte ranges → HLS conversion → cleanup',{timeout:60000},async t=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'sideline-torrent-test-'));
  const sample=path.join(dir,'owned-test-video.mp4');
  const generated=spawnSync('ffmpeg',['-v','error','-f','lavfi','-i','color=c=green:s=320x180:r=24','-f','lavfi','-i','sine=frequency=440:sample_rate=48000','-t','8','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-movflags','+faststart',sample]);assert.equal(generated.status,0,'FFmpeg test fixture generation');
  const seedClient=new WebTorrent(clientOptions);seedClient.on('error',()=>{});
  const seeded=await new Promise((resolve,reject)=>{const x=seedClient.seed(sample,{announce:[]},resolve);x.on('error',reject)});
  const downloader=new WebTorrent(clientOptions);downloader.on('error',e=>console.error('Local test client:',e.message));const originalAdd=downloader.add.bind(downloader);downloader.add=(...args)=>{const torrent=originalAdd(...args);torrent.on('error',e=>console.error('Local test torrent:',e.message));return torrent};
  const config={apiKey:crypto.randomBytes(32).toString('hex'),secret:crypto.randomBytes(32).toString('hex'),publicURL:'http://127.0.0.1',origin:'https://app.example',host:'127.0.0.1',port:0,dataDir:path.join(dir,'cache'),maxSessions:2,maxBytes:1024**3,idleMs:60000,ticketMs:60000,maxTranscodes:1,ffmpeg:'ffmpeg'};
  const app=createStreamingServer(config,downloader);app.server.listen(0,'127.0.0.1');await once(app.server,'listening');const base='http://127.0.0.1:'+app.server.address().port;config.publicURL=base;
  t.after(async()=>{await app.close();await new Promise(r=>seedClient.destroy(r));await rm(dir,{recursive:true,force:true})});
  const headers={Authorization:'Bearer '+config.apiKey,'Content-Type':'application/json',Origin:config.origin};
  assert.equal((await fetch(base+'/api/info')).status,401);
  assert.equal((await fetch(base+'/api/info',{headers:{...headers,Origin:'https://evil.example'}})).status,403);
  assert.equal((await fetch(base+'/api/info',{headers})).status,200);
  const pending=fetch(base+'/api/sessions',{method:'POST',headers,body:JSON.stringify({magnet:seeded.magnetURI})});
  await poll(()=>app.jobs.size&&[...app.jobs.values()][0]?.torrent);const job=[...app.jobs.values()][0];job.torrent.addPeer('127.0.0.1:'+seedClient.torrentPort);
  const created=await pending;assert.equal(created.status,202);const id=(await created.json()).id;
  const ready=await poll(async()=>{const v=await (await fetch(base+'/api/sessions/'+id,{headers})).json();return v.state==='ready'?v:null});assert.equal(ready.files.length,1);
  const playing=await (await fetch(base+'/api/sessions/'+id+'/play',{method:'POST',headers,body:JSON.stringify({fileIndex:0,mode:'direct'})})).json();assert(playing.playback.url);
  const media=playing.playback.url,expected=await readFile(sample);
  const partial=await fetch(media,{headers:{Range:'bytes=0-255',Origin:config.origin}});assert.equal(partial.status,206);assert.equal(partial.headers.get('access-control-allow-origin'),config.origin);assert.deepEqual(Buffer.from(await partial.arrayBuffer()),expected.subarray(0,256));
  const suffix=await fetch(media,{headers:{Range:'bytes=-128'}});assert.equal(suffix.status,206);assert.deepEqual(Buffer.from(await suffix.arrayBuffer()),expected.subarray(-128));
  const invalid=new URL(media);invalid.searchParams.set('t','invalid');assert.equal((await fetch(invalid)).status,401);
  assert.equal((await fetch(media.split('?')[0])).status,401);
  assert.equal((await fetch(media,{headers:{Range:'bytes=999999999999-'}})).status,416);
  const full=Buffer.from(await (await fetch(media)).arrayBuffer());assert.deepEqual(full,expected);
  await fetch(base+'/api/sessions/'+id+'/play',{method:'POST',headers,body:JSON.stringify({fileIndex:0,mode:'hls'})});
  const hls=await poll(async()=>{const v=await(await fetch(base+'/api/sessions/'+id,{headers})).json();if(v.transcodeError)throw new Error(v.transcodeError);return v.playback?.mode==='hls'?v.playback:null},20000);
  const playlist=await(await fetch(hls.url)).text();assert(playlist.includes('#EXTM3U'));const segment=playlist.split('\n').find(l=>l&&!l.startsWith('#'));assert(segment.includes('?e=')&&segment.includes('&t='));const segmentURL=new URL(segment,hls.url);const segmentResponse=await fetch(segmentURL);assert.equal(segmentResponse.status,200);assert((await segmentResponse.arrayBuffer()).byteLength>100);
  assert.equal((await fetch(new URL(segment.split('?')[0],hls.url))).status,401);
  assert.equal((await fetch(base+'/api/sessions/'+id,{method:'DELETE',headers})).status,200);
  assert.equal((await fetch(media)).status,404);
});
