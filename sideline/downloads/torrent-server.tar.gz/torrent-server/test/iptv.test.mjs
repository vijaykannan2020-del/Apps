import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { promises as fs } from 'node:fs';
import { spawn } from 'node:child_process';
import { normalizeMac, normalizePortal, isBlockedHost, createPortalClient, ffmpegArgs, MAG_UA } from '../iptv.mjs';
import { createStreamingServer } from '../server.mjs';

test('MAC, portal and host checks', () => {
  assert.equal(normalizeMac('00-1a-79-ab-cd-ef'), '00:1A:79:AB:CD:EF');
  assert.equal(normalizeMac('001A79ABCDEF'), '00:1A:79:AB:CD:EF');
  assert.throws(() => normalizeMac('00:1A:79\r\nX: y'));
  assert.equal(normalizePortal('line.example.com:8080/c/'), 'http://line.example.com:8080');
  assert.throws(() => normalizePortal('http://192.168.1.5/c/'));
  for (const bad of ['http://127.0.0.1/x', 'http://10.0.0.1', 'http://localhost:80', 'http://[::1]/', 'file:///etc/passwd', 'http://169.254.169.254/'])
    assert.equal(isBlockedHost(bad), true, bad);
  for (const ok of ['http://fdn.example.com/a.ts', 'http://line.tv:8080/play/1', 'https://8.8.8.8/x']) assert.equal(isBlockedHost(ok), false, ok);
});

test('portal client logs in as a MAG box and resolves links', async () => {
  const seen = [];
  const fake = async (url, opts) => {
    url = new URL(url); seen.push({ path: url.pathname, action: url.searchParams.get('action'), h: opts.headers });
    const js = { handshake: { token: 'TOK' }, get_profile: {}, get_genres: [{ id: '1', title: 'Tamil' }, { id: '2', title: 'Sports' }],
      get_all_channels: { data: [{ id: 5, name: 'Sun TV', cmd: 'ffmpeg http://localhost/ch/5', tv_genre_id: '1' }, { id: 6, name: 'Willow', cmd: 'ffmpeg http://localhost/ch/6', tv_genre_id: '2' }] },
      create_link: { cmd: 'ffmpeg http://stream.example.com/live/abc/5.ts?play_token=x' } }[url.searchParams.get('action')];
    if (url.pathname !== '/stalker_portal/server/load.php') return new Response('not here', { status: 404 });
    return new Response(JSON.stringify({ js }), { status: 200 });
  };
  const p = createPortalClient(fake);
  const r = await p.channels('http://portal.example.com', '00:1A:79:AB:CD:EF');
  assert.deepEqual(r.categories, ['Tamil', 'Sports']);
  assert.equal(r.channels[0].name, 'Sun TV');
  const hs = seen.find(s => s.action === 'handshake' && s.path === '/stalker_portal/server/load.php');
  assert.match(hs.h['User-Agent'], /MAG200/);
  assert.equal(hs.h['X-User-MAC'], '00:1A:79:AB:CD:EF');
  assert.match(hs.h.Cookie, /mac=00:1A:79:AB:CD:EF/);
  assert.equal(seen.find(s => s.action === 'get_all_channels').h.Authorization, 'Bearer TOK');
  assert.equal(await p.link('http://portal.example.com', '00:1A:79:AB:CD:EF', 'ffmpeg http://localhost/ch/5'), 'http://stream.example.com/live/abc/5.ts?play_token=x');
});

test('ffmpeg args carry MAG headers', () => {
  const a = ffmpegArgs({ target: 'http://x/1.ts', mac: '00:1A:79:AB:CD:EF', origin: 'http://p', dir: '/tmp/d', convert: false });
  assert.equal(a[a.indexOf('-user_agent') + 1], MAG_UA);
  assert.match(a[a.indexOf('-headers') + 1], /X-User-MAC: 00:1A:79:AB:CD:EF\r\n.*Cookie: mac=00:1A:79:AB:CD:EF/s);
  assert.equal(a[a.indexOf('-c:v') + 1], 'copy');
});

test('end to end: channel list, live HLS for Safari, auth, expiry', { timeout: 90000 }, async () => {
  // Fake IPTV stream server that only answers MAG boxes with the right MAC (like a real provider).
  const tsFile = path.join(os.tmpdir(), 'iptv-test-' + process.pid + '.ts');
  await new Promise((ok, bad) => spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'lavfi', '-i', 'testsrc=size=320x240:rate=25', '-f', 'lavfi', '-i', 'sine=frequency=440',
    '-t', '20', '-c:v', 'libx264', '-preset', 'ultrafast', '-g', '25', '-c:a', 'mp2', '-f', 'mpegts', tsFile]).on('exit', c => (c === 0 ? ok() : bad(new Error('ffmpeg ' + c)))));
  let macSeen = null;
  const media = http.createServer(async (req, res) => {
    macSeen = req.headers['x-user-mac'];
    if (!/MAG200/.test(req.headers['user-agent'] || '') || req.headers['x-user-mac'] !== '00:1A:79:AB:CD:EF') { res.writeHead(403); res.end(); return; }
    res.writeHead(200, { 'Content-Type': 'video/mp2t' });
    const data = await fs.readFile(tsFile); let i = 0;
    const t = setInterval(() => { if (i >= data.length || res.destroyed) { clearInterval(t); res.end(); return; } res.write(data.subarray(i, i += 188 * 400)); }, 50);
  });
  await new Promise(r => media.listen(0, '127.0.0.1', r));
  const target = `http://127.0.0.1:${media.address().port}/live/5.ts`;
  const portal = { channels: async () => ({ categories: ['Tamil'], channels: [{ id: '5', name: 'Sun TV', cmd: 'ffmpeg http://localhost/ch/5', category: 'Tamil' }] }), link: async () => target };

  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), 'bridge-'));
  const config = { apiKey: 'k'.repeat(40), secret: 's'.repeat(40), publicURL: 'http://placeholder', host: '127.0.0.1', port: 0, dataDir, origin: 'https://vijaykannan2020-del.github.io',
    maxSessions: 1, maxBytes: 1e9, idleMs: 60000, ticketMs: 3600000, maxTranscodes: 1, ffmpeg: 'ffmpeg', peerPort: 0, maxIptv: 1 };
  const fakeClient = { on() {}, add() {}, remove(_, __, cb) { cb(); }, destroy(cb) { cb(); } };
  const app = createStreamingServer(config, fakeClient);
  // swap in the fake portal
  const { createIptv } = await import('../iptv.mjs');
  await new Promise(r => app.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.server.address().port}`; config.publicURL = base;
  const crypto = await import('node:crypto');
  const sig = (id, index, e) => crypto.createHmac('sha256', config.secret).update(`${id}:${index}:${e}`).digest('base64url');
  const eq = (a, b) => a === b;
  const json = (res, s, v) => { res.writeHead(s, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(v)); };
  const body = async req => { let d = ''; for await (const c of req) d += c; return JSON.parse(d || '{}'); };
  const iptv = createIptv({ config, signature: sig, equal: eq, json, body, portal });
  app.server.removeAllListeners('request');
  app.server.on('request', async (req, res) => {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/api/') && req.headers.authorization !== 'Bearer ' + config.apiKey) return json(res, 401, { error: 'key' });
    if (await iptv.handleApi(req, res, url.pathname)) return;
    if (await iptv.handleMedia(req, res, url, url.pathname)) return;
    json(res, 404, {});
  });
  const H = { Authorization: 'Bearer ' + config.apiKey, 'Content-Type': 'application/json' };
  try {
    const ch = await (await fetch(base + '/api/iptv/channels', { method: 'POST', headers: H, body: JSON.stringify({ portal: 'http://portal.example.com', mac: '001a79abcdef' }) })).json();
    assert.equal(ch.channels[0].name, 'Sun TV');
    const play = await (await fetch(base + '/api/iptv/play', { method: 'POST', headers: H, body: JSON.stringify({ portal: 'http://portal.example.com', mac: '00:1a:79:ab:cd:ef', cmd: 'ffmpeg http://localhost/ch/5', name: 'Sun TV' }) })).json();
    assert.ok(play.hls, JSON.stringify(play));
    assert.equal(macSeen, '00:1A:79:AB:CD:EF');
    const pl = await fetch(play.hls); assert.equal(pl.status, 200);
    const text = await pl.text(); assert.match(text, /#EXTINF/);
    const seg = text.split('\n').find(l => l.startsWith('seg-'));
    const s = await fetch(new URL(seg, play.hls)); assert.equal(s.status, 200);
    const buf = Buffer.from(await s.arrayBuffer()); assert.ok(buf.length > 1000); assert.equal(buf[0], 0x47); // MPEG-TS sync byte
    // audio was mp2 at the source; Safari needs AAC — check it was converted
    const probe = await new Promise(ok => { let o = ''; const p = spawn('ffprobe', ['-v', 'error', '-show_entries', 'stream=codec_name', '-of', 'csv=p=0', '-']); p.stdout.on('data', d => o += d); p.on('exit', () => ok(o)); p.stdin.end(buf); });
    assert.match(probe, /h264/); assert.match(probe, /aac/);
    // tampered / missing ticket rejected
    assert.equal((await fetch(play.hls.replace(/t=[^&]+/, 't=bad'))).status, 401);
    assert.equal((await fetch(base + '/api/iptv/channels', { method: 'POST', body: '{}' })).status, 401);
    // stop
    assert.equal((await fetch(base + '/api/iptv/stop', { method: 'POST', headers: H, body: '{}' })).status, 200);
    assert.equal(iptv.lives.size, 0);
    assert.equal((await fetch(play.hls)).status, 404);
  } finally {
    await iptv.close(); await new Promise(r => app.server.close(r)); await new Promise(r => media.close(r));
    media.closeAllConnections?.(); await fs.rm(dataDir, { recursive: true, force: true }); await fs.rm(tsFile, { force: true });
  }
});

test('STB model / user-agent threads through to portal and ffmpeg', async () => {
  const { cleanUA, cleanModel, ffmpegArgs, createPortalClient } = await import('../iptv.mjs');
  assert.equal(cleanUA('bad\r\nInjected: x'), 'badInjected: x');
  assert.equal(cleanUA('x'), null);
  assert.equal(cleanModel('AuraHD9'), 'AuraHD9');
  assert.equal(cleanModel(''), 'MAG200');
  const AURA = 'Mozilla/5.0 AuraHD9 test agent';
  let seen;
  const fake = async (url, opts) => { seen = opts.headers; const a = new URL(url).searchParams.get('action');
    const js = { handshake:{token:'T'}, get_profile:{}, create_link:{cmd:'ffmpeg http://s/1.ts'} }[a];
    if (new URL(url).pathname !== '/portal.php') return new Response('x',{status:404});
    return new Response(JSON.stringify({js}),{status:200}); };
  const p = createPortalClient(fake);
  await p.link('http://x.tv', '1A:17:E3:AB:7B:DF', 'cmd', { ua: AURA, model: 'AuraHD9' });
  assert.equal(seen['User-Agent'], AURA);
  assert.equal(seen['X-User-Agent'], 'Model: AuraHD9; Link: WiFi');
  const args = ffmpegArgs({ target:'http://s/1.ts', mac:'1A:17:E3:AB:7B:DF', origin:'http://x.tv', dir:'/tmp/d', convert:false, agent:{ ua: AURA, model:'AuraHD9' } });
  assert.equal(args[args.indexOf('-user_agent')+1], AURA);
  assert.match(args[args.indexOf('-headers')+1], /X-User-Agent: Model: AuraHD9/);
});
