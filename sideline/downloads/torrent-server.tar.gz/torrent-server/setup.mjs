import {randomBytes} from 'node:crypto';
import {writeFile} from 'node:fs/promises';
const host=process.argv[2]||'streams.example.com';
if(!/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/i.test(host))throw new Error('Pass a DNS hostname, for example: node setup.mjs streams.your-domain.com');
const text=`SERVER_HOST=${host}\nAPP_ORIGIN=https://sideline-live-tv-8742.verdantcaper.chatgpt.site\nAPI_KEY=${randomBytes(32).toString('hex')}\nSTREAM_SECRET=${randomBytes(32).toString('hex')}\nMAX_SESSIONS=3\nMAX_TORRENT_GB=12\nIDLE_MINUTES=30\nTICKET_HOURS=6\n`;
try{await writeFile(new URL('.env',import.meta.url),text,{flag:'wx',mode:0o600});console.log('Created private .env configuration. Open that file locally to copy API_KEY into your app. Keep STREAM_SECRET on the server.')}catch(e){if(e.code==='EEXIST')console.log('An .env file already exists; it was preserved.');else throw e}
